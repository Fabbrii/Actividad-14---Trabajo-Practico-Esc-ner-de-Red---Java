package EscanerRed;

import javax.swing.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ScannerWorker extends SwingWorker<List<Dispositivo>, Integer> {

    private final String ipInicio;
    private final String ipFin;
    private final int timeoutMs;
    private final DeviceTableModel tableModel;

    public ScannerWorker(String ipInicio, String ipFin, int timeoutMs, DeviceTableModel tableModel) {
        this.ipInicio = ipInicio;
        this.ipFin = ipFin;
        this.timeoutMs = timeoutMs;
        this.tableModel = tableModel;
    }

    @Override
    protected List<Dispositivo> doInBackground() {
        List<Dispositivo> resultados = new ArrayList<>();
        long start = IPUtils.ipToLong(ipInicio);
        long end = IPUtils.ipToLong(ipFin);
        if (end < start) { long tmp = start; start = end; end = tmp; }
        long total = end - start + 1;
        long contador = 0;

        for (long cur = start; cur <= end && !isCancelled(); cur++) {
            contador++;
            String ip = IPUtils.longToIp(cur);
            Dispositivo d = new Dispositivo(ip);
            try {
                long t0 = System.nanoTime();
                boolean reachable = ping(ip, timeoutMs);
                long t1 = System.nanoTime();
                d.setConectado(reachable);
                if (reachable) d.setTiempoMs(TimeUnit.NANOSECONDS.toMillis(t1 - t0));
                d.setNombre(resolverNombre(ip));
            } catch (Exception ex) {
                d.setConectado(false);
                d.setTiempoMs(-1);
                d.setNombre("");
            }
            resultados.add(d);
            publish((int) ((contador * 100) / total));
        }
        return resultados;
    }

    @Override
    protected void process(List<Integer> chunks) {
        if (!chunks.isEmpty()) tableModel.setProgress(chunks.get(chunks.size() - 1));
    }

    @Override
    protected void done() {
        try {
            tableModel.setResultados(get());
            tableModel.setProgress(100);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error durante el escaneo: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean ping(String ip, int timeoutMs) throws IOException, InterruptedException {
        boolean windows = System.getProperty("os.name").toLowerCase().contains("win");
        ProcessBuilder pb;
        if (windows)
            pb = new ProcessBuilder("ping", "-n", "1", "-w", String.valueOf(timeoutMs), ip);
        else
            pb = new ProcessBuilder("ping", "-c", "1", "-W", String.valueOf(Math.max(1, (int) Math.ceil(timeoutMs / 1000.0))), ip);

        Process p = pb.start();
        boolean finished = p.waitFor(timeoutMs + 2000, TimeUnit.MILLISECONDS);
        if (!finished) { p.destroyForcibly(); return false; }
        return p.exitValue() == 0;
    }

    private String resolverNombre(String ip) throws IOException, InterruptedException {
        ProcessBuilder pb = new ProcessBuilder("nslookup", ip);
        Process p = pb.start();
        BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String linea, nombre = "";
        while ((linea = in.readLine()) != null) {
            linea = linea.trim().toLowerCase();
            if (linea.contains("name =")) {
                nombre = linea.substring(linea.indexOf("=") + 1).trim();
                break;
            }
        }
        p.waitFor(2000, TimeUnit.MILLISECONDS);
        in.close();
        return nombre;
    }
}