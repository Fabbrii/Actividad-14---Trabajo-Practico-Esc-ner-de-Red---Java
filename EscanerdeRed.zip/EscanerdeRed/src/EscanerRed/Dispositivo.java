package EscanerRed;

public class Dispositivo {
    private String ip;
    private String nombre;
    private boolean conectado;
    private long tiempoMs;

    public Dispositivo(String ip) {
        this.ip = ip;
        this.nombre = "";
        this.conectado = false;
        this.tiempoMs = -1;
    }

    public String getIp() { return ip; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public boolean isConectado() { return conectado; }
    public void setConectado(boolean conectado) { this.conectado = conectado; }
    public long getTiempoMs() { return tiempoMs; }
    public void setTiempoMs(long tiempoMs) { this.tiempoMs = tiempoMs; }
}

