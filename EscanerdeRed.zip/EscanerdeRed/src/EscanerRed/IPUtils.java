package EscanerRed;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class IPUtils {
    private static final Pattern IP_PATTERN = Pattern.compile(
            "^(25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]\\d?|0)\\." +
            "(25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]\\d?|0)\\." +
            "(25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]\\d?|0)\\." +
            "(25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]\\d?|0)$");

    public static boolean validarIp(String ip) {
        if (ip == null) return false;
        Matcher m = IP_PATTERN.matcher(ip.trim());
        return m.matches();
    }

    public static long ipToLong(String ip) {
        String[] parts = ip.split("\\.");
        long res = 0;
        for (int i = 0; i < 4; i++) {
            res = (res << 8) + Integer.parseInt(parts[i]);
        }
        return res;
    }

    public static String longToIp(long val) {
        return String.format("%d.%d.%d.%d",
                (val >> 24) & 0xFF,
                (val >> 16) & 0xFF,
                (val >> 8) & 0xFF,
                val & 0xFF);
    }
}