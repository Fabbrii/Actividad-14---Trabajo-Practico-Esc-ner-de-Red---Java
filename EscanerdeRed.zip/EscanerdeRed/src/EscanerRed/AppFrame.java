package EscanerRed;

import javax.swing.*;
import java.awt.*;

public class AppFrame extends JFrame {
    private JTextField campoInicio;
    private JTextField campoFin;
    private JButton botonEscanear;
    private JTable tabla;
    private DeviceTableModel modeloTabla;

    public AppFrame() {
        setTitle("Escáner de Red");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelSuperior = new JPanel(new FlowLayout());
        panelSuperior.add(new JLabel("IP Inicio:"));
        campoInicio = new JTextField(10);
        panelSuperior.add(campoInicio);

        panelSuperior.add(new JLabel("IP Fin:"));
        campoFin = new JTextField(10);
        panelSuperior.add(campoFin);

        botonEscanear = new JButton("Escanear");
        panelSuperior.add(botonEscanear);

        add(panelSuperior, BorderLayout.NORTH);

        modeloTabla = new DeviceTableModel();
        tabla = new JTable(modeloTabla);
        add(new JScrollPane(tabla), BorderLayout.CENTER);

        botonEscanear.addActionListener(e -> iniciarEscaneo());
    }

    private void iniciarEscaneo() {
        String inicio = campoInicio.getText().trim();
        String fin = campoFin.getText().trim();

        if (!IPUtils.validarIp(inicio) || !IPUtils.validarIp(fin)) {
            JOptionPane.showMessageDialog(this, "IP inválida", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Reinicia el modelo de la tabla para el nuevo escaneo, modificando la variable de instancia.
        // **Importante:** Elimina el "DeviceTableModel" de aquí.
        modeloTabla = new DeviceTableModel();
        tabla.setModel(modeloTabla);

        ScannerWorker worker = new ScannerWorker(inicio, fin, 1, modeloTabla);
        worker.execute();
    }
}