package EscanerRed;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

public class DeviceTableModel extends AbstractTableModel {
    private final String[] columnas = {"IP", "Nombre", "Conectado", "Tiempo (ms)"};
    private List<Dispositivo> datos = new ArrayList<>();
    private int progreso = 0;

    public void setResultados(List<Dispositivo> res) {
        this.datos = res;
        fireTableDataChanged();
    }

    public List<Dispositivo> getResultados() { return datos; }
    public void setProgress(int p) { this.progreso = p; }
    public int getProgress() { return progreso; }

    @Override
    public int getRowCount() { return datos.size(); }
    @Override
    public int getColumnCount() { return columnas.length; }
    @Override
    public String getColumnName(int column) { return columnas[column]; }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Dispositivo d = datos.get(rowIndex);
        switch (columnIndex) {
            case 0: return d.getIp();
            case 1: return d.getNombre();
            case 2: return d.isConectado() ? "Sí" : "No";
            case 3: return d.getTiempoMs() >= 0 ? d.getTiempoMs() : "-";
            default: return "";
        }
    }

    public int countRespondieron() {
        int c = 0;
        for (Dispositivo d : datos) if (d.isConectado()) c++;
        return c;
    }
}